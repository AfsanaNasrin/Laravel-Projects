<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Laravel Ecommerce Project</title>

@include('partials.styles')
  </head>
  <body>

<div class="wrapper">
<!-- Navigation -->
@include('partials.nav')
<!-- End Navigation -->


@yield('content')

@include('partials.footer')

@include('partials.scripts')

  </body>
</html>
