@extends('layouts.master')

@section('content')
<div class='container margin-top-20'>
   <h2>This is Contact Part</h2>
   <p>Thanks Allah For giving me patience</p>
</div>
@endsection
