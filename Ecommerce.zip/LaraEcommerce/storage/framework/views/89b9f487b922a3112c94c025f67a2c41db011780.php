


<?php $__env->startSection('content'); ?>

<!-- Start Side bar and content -->
<div class='container .margin-top-20{
  margin-top:20px
}'>
  <div class="row">
    <div class="col-md-4">
      <div class="list-group ">
        <a href="#" class="list-group-item list-group-item-action">1st</a>
        <a href="#" class="list-group-item list-group-item-action">2nd</a>
        <a href="#" class="list-group-item list-group-item-action">3rd</a>
      </div>
    </div>
    <div class="col-md-8">
      <div class="widget">
          <h3>Featured Product</h3>
          <div class="row">

            <div class="col-md-3">
              <div class="card">
                <img class="card-img-top feature-img" src="<?php echo e(asset('images/products/'.'oppo.jpg')); ?>" alt="Card image">
                <div class="card-body">
                <h4 class="card-title">oppo</h4>
                <p class="card-text">Tk.15k</p>
                <a href="#" class="btn btn-outline-warning">Add to Cart</a>
                 </div>
              </div>
            </div>

            <div class="col-md-3">
              <div class="card">
                <img class="card-img-top feature-img" src="<?php echo e(asset('images/products/'.'VivoS1.jpg')); ?>" alt="Card image">
                <div class="card-body">
                <h4 class="card-title">Vivo</h4>
                <p class="card-text">Tk.24k</p>
                <a href="#" class="btn btn-outline-warning">Add to Cart</a>
                 </div>
              </div>
            </div>

            <div class="col-md-3">
              <div class="card">
                <img class="card-img-top feature-img" src="<?php echo e(asset('images/products/'.'oppo.jpg')); ?>" alt="Card image">
                <div class="card-body">
                <h4 class="card-title">oppo</h4>
                <p class="card-text">Tk.15k</p>
                <a href="#" class="btn btn-outline-warning">SAdd to Cart</a>
                 </div>
              </div>
            </div>

            <div class="col-md-3">
              <div class="card">
                <img class="card-img-top feature-img" src="<?php echo e(asset('images/products/'.'VivoS1.jpg')); ?>" alt="Card image">
                <div class="card-body">
                <h4 class="card-title">Vivo</h4>
                <p class="card-text">Tk.24k</p>
                <a href="#" class="btn btn-outline-warning">Add to Cart</a>
                 </div>
              </div>
            </div>

            <div class="col-md-3">
              <div class="card">
                <img class="card-img-top feature-img" src="<?php echo e(asset('images/products/'.'VivoS1.jpg')); ?>" alt="Card image">
                <div class="card-body">
                <h4 class="card-title">Vivo</h4>
                <p class="card-text">Tk.24k</p>
                <a href="#" class="btn btn-outline-warning">Add to Cart</a>
                 </div>
              </div>
            </div>

            <div class="col-md-3">
              <div class="card">
                <img class="card-img-top feature-img" src="<?php echo e(asset('images/products/'.'VivoS1.jpg')); ?>" alt="Card image">
                <div class="card-body">
                <h4 class="card-title">Vivo</h4>
                <p class="card-text">Tk.24k</p>
                <a href="#" class="btn btn-outline-warning">Add to Cart</a>
                 </div>
              </div>
            </div>

            <div class="col-md-3">
              <div class="card">
                <img class="card-img-top feature-img" src="<?php echo e(asset('images/products/'.'VivoS1.jpg')); ?>" alt="Card image">
                <div class="card-body">
                <h4 class="card-title">Vivo</h4>
                <p class="card-text">Tk.24k</p>
                <a href="#" class="btn btn-outline-warning">Add to Cart</a>
                 </div>
              </div>
            </div>

            <div class="col-md-3">
              <div class="card">
                <img class="card-img-top feature-img" src="<?php echo e(asset('images/products/'.'VivoS1.jpg')); ?>" alt="Card image">
                <div class="card-body">
                <h4 class="card-title">Vivo</h4>
                <p class="card-text">Tk.24k</p>
                <a href="#" class="btn btn-outline-warning">Add to Cart</a>
                 </div>
              </div>
            </div>

         </div>
      </div>


    </div>

  </div>
 </div>
</div>
<!-- End Side bar and content -->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LaraEcommerce\resources\views/pages/product/index.blade.php ENDPATH**/ ?>